package helper;

public enum Action {
    DELETE,
    EDIT;
}
